BRADBURY CREEK - GENRE BACKGROUNDS

1. Unzip this package.
2. In your GitHub repository, replace bookshelf.html, bookshelf.css, and bookshelf.js with the versions in this folder. Upload these three files to the repository root (alongside index.html and style.css).
3. Make sure your existing book cover files are in assets/ and filenames match the image paths in bookshelf.js.
4. In index.html, ensure the navigation link reads <a href="bookshelf.html">Bookshelf</a>.
5. Commit changes and refresh your published GitHub Pages website.

When a book is clicked, its detail popup background changes according to the book genre. The main library remains a multi-genre theme. Edit the genre field in bookshelf.js to choose a background.
